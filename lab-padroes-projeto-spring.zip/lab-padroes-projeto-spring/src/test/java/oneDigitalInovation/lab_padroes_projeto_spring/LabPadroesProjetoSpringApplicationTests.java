package oneDigitalInovation.lab_padroes_projeto_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabPadroesProjetoSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
